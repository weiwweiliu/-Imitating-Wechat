package com.itcast.mynetty;


import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * @program: NettyPro
 * @description:
 * @author: Lww
 * @create: 2020/11/19
 */
public class LwwGroupChatClientHandler extends SimpleChannelInboundHandler<String> {

    //读取数据
    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, String s) throws Exception {
        System.out.println(s.trim());


        new MainActivity().addNewMessage(s,1);

    }

}
