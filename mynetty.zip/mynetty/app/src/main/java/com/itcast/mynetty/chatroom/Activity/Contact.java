package com.itcast.mynetty.chatroom.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

//import com.example.qq.contact.Child_Ex;
//import com.example.qq.contact.Father_Ex;
//import com.example.qq.contact.MyBaseExpandableListAdapter;
import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Activity.secondaryActivity.Friendspage;
import com.itcast.mynetty.chatroom.indexlistview.SideBar;
import com.itcast.mynetty.chatroom.indexlistview.SortAdapter;
import com.itcast.mynetty.chatroom.indexlistview.User;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * 2020  5 16
 * @author  weiwei
 * @version  1.0
 */

//第2个 View   联系人
    //主要为设置页面数据
public class Contact extends Fragment  {
        private ListView listView;
    private SideBar sideBar;
    private ArrayList<User> list;
    private Context mContext;
    public Contact() {
    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


            View view = inflater.inflate(R.layout.activity_contacts,container,false);
//        TextView txt_content = (TextView) view.findViewById(R.id.myname);
            mContext = getContext();//Contact.this;
            listView = (ListView) view.findViewById(R.id.listView);
            sideBar = (SideBar) view.findViewById(R.id.side_bar);

            initView();//初始化
            initData();//数据加载
            return  view;
    }
private void initView() {

    sideBar.setOnStrSelectCallBack(new SideBar.ISideBarSelectCallBack() {
        @Override
        public void onSelectStr(int index, String selectStr) {
            for (int i = 0; i < list.size(); i++) {
                if (selectStr.equalsIgnoreCase(list.get(i).getFirstLetter())) {
                    listView.setSelection(i); // 选择到首字母出现的位置
                    return;
                }
            }
        }
    });

    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

        @Override
        //arg2 视图在adapter的位置， arg3 点击元素的行id
        public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) {


            Bundle bundle = new Bundle();
            bundle.putString("ContactName", list.get(arg2).getName());
            bundle.putInt("userId", list.get(arg2).getUserId());
            Intent intent = new Intent();
            intent.putExtras(bundle);
            intent.setClass(requireActivity(), Friendspage.class);
            startActivity(intent);
        }
    });
}

    private void initData() {
        list = new ArrayList<>();
        list.add(new User("羽冬夜 ",R.mipmap.head2));
        list.add(new User("步月华 ",R.mipmap.head2));
        list.add(new User("屵",R.mipmap.head1));
        list.add(new User("菊月 ",R.mipmap.head2));
        list.add(new User("紫纱 ",R.mipmap.head3));
        list.add(new User("白采铃 ",R.mipmap.head4));
        list.add(new User("茶草洵 ",R.mipmap.head5));
        list.add(new User("穷尽",R.mipmap.head6));
        list.add(new User("阿辽莎 ",R.mipmap.head7));
        list.add(new User("梅利",R.mipmap.head8));
        list.add(new User("雨桐 ",R.mipmap.head9));
        list.add(new User("繁昔 ",R.mipmap.head10));
        list.add(new User("兰斯",R.mipmap.head11));
        list.add(new User("绮白",R.mipmap.head12));
        list.add(new User("君莫邪 ",R.mipmap.head13));
        list.add(new User("红莲",R.mipmap.head14));
        list.add(new User("宋喆",R.mipmap.head15));
        list.add(new User("何丹",R.mipmap.head16));
        list.add(new User("苏吉",R.mipmap.head17));
        list.add(new User("依铃",R.mipmap.head18));
        list.add(new User("海霞",R.mipmap.head19));
        list.add(new User("蓝雪那 ",R.mipmap.head20));
        list.add(new User("霜天晓 ",R.mipmap.head3));
        list.add(new User("南无",R.mipmap.head3));
        list.add(new User("玛丽",R.mipmap.head3));
        list.add(new User("琦玮",R.mipmap.head3));
        list.add(new User("歌妖",R.mipmap.head3));
        list.add(new User("带土",R.mipmap.head3));
        list.add(new User("和畅",R.mipmap.head3));
        list.add(new User("小野",R.mipmap.head3));
        list.add(new User("莱斯特",R.mipmap.head3));
        list.add(new User("澄泓",R.mipmap.head3));
        list.add(new User("飘雪",R.mipmap.head3));
        list.add(new User("凤雪痕",R.mipmap.head3));
        list.add(new User("姜景勋",R.mipmap.head3));
        list.add(new User("Tom",R.mipmap.head3));
        list.add(new User("Jerry",R.mipmap.head3));
        list.add(new User("12345",R.mipmap.head3));
        list.add(new User("闻人秋夜 ",R.mipmap.head3));
        list.add(new User("_(:з」∠)_",R.mipmap.head2));
        list.add(new User("……%￥#￥%#",R.mipmap.head1));
        Collections.sort(list); // 对list进行排序，需要让User实现Comparable接口重写compareTo方法
        SortAdapter adapter = new SortAdapter(mContext, list);
        listView.setAdapter(adapter);
    }
}

