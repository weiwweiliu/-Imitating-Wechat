package com.itcast.mynetty.chatroom.sqlitelogin.service;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 *
 * 2020  5 19
 * @author  weiwei
 * @version  1.0
 */
public class DatabaseHelper2 extends SQLiteOpenHelper {
    static String name="person.db";
    static int dbVersion=1;
    public DatabaseHelper2(Context context) {
        super(context, name, null, dbVersion);
    }

    public void onCreate(SQLiteDatabase db) {
        String sql="create table person(id integer primary key autoincrement,name varchar(20),autograph varchar(20),sex varchar(2))";
        db.execSQL(sql);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
