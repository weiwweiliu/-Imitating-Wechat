package com.itcast.mynetty.chatroom.Adapter;

import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import  com.itcast.mynetty.R;
//广告位类型ViewHolder
public class SectionHolder extends RecyclerView.ViewHolder {
    ImageView mIv_bg;

    SectionHolder(@NonNull View itemView) {
        super(itemView);
        mIv_bg = itemView.findViewById(R.id.iv_bg);
    }
}
