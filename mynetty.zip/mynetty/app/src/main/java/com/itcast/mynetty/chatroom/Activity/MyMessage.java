package com.itcast.mynetty.chatroom.Activity;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Activity.secondaryActivity.Message2;
import com.itcast.mynetty.chatroom.Adapter.SpacesItemDecoration;

//第四页 个人界面，用于修改个人头像，名称
public class MyMessage extends Fragment implements View.OnClickListener{
    private ImageButton userImage;
    private RecyclerView recyclerView;
    private MyMessage.HomeAdapter adapter;
    private  String [] title ={"支付","收藏","相册","卡包","表情","设置"};
    private  int [] icon={R.mipmap.payment,R.mipmap.collection,R.mipmap.album,R.mipmap.mycard,R.mipmap.expression,R.mipmap.setup};
    public MyMessage() {


    }
    //动态页面
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_message, container, false);
        Log.e("HEHE", "第三个");
        //view.findViewById(R.drawable.blue)
        recyclerView =(RecyclerView) view.findViewById(R.id.messageRecyler);
        userImage=(ImageButton)view.findViewById(R.id.userImage);
        //设置间隔为8
        int spacingInPixels = 8;
        recyclerView.addItemDecoration( new SpacesItemDecoration(spacingInPixels));

        //初始化
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter =new MyMessage.HomeAdapter();
        recyclerView.setAdapter(adapter);

        //监听事件
        userImage.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        if(v==userImage){
            Bundle bundle = new Bundle();
           // bundle.putInt("photo", userId);
            //  bundle.putString("message", message[arg2]);
         //   bundle.putString("name",ContactName);
            Intent intent = new Intent();
            intent.setClass(requireActivity(),Message2.class);
            intent.putExtras(bundle);

            startActivity(intent);

        }

    }

    class  HomeAdapter extends RecyclerView.Adapter<MyMessage.HomeAdapter.MyViewHolder>
    {


        @NonNull
        @Override
        public MyMessage.HomeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MyMessage.HomeAdapter.MyViewHolder holder = new MyMessage.HomeAdapter.MyViewHolder(getLayoutInflater().from(getActivity()).inflate(R.layout.recycler_item,parent,false));

            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyMessage.HomeAdapter.MyViewHolder holder, int position) {
            holder.rl_title.setText(title[position]);
            holder.imageView.setBackgroundResource(icon[position]);
        }



        @Override
        public int getItemCount() {
            return title.length;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView rl_title;
            ImageView imageView;
            public  MyViewHolder(View view)
            {
                super(view);
                rl_title =(TextView) view.findViewById(R.id.rl_name);
                imageView =(ImageView)view.findViewById(R.id.rl_iv);
            }






        }
    }
}
//更改间隔
// class SpacesItemDecoration extends RecyclerView.ItemDecoration {
//    private int space;
//    public SpacesItemDecoration(int space) {
//        this.space = space;
//    }
//    @Override
//    public void getItemOffsets(Rect outRect, View view,
//                               RecyclerView parent, RecyclerView.State state) {
//        outRect.left = space;
//        outRect.right = space;
//        outRect.bottom = space;
//        // Add top margin only for the first item to avoid double space between items
//        if (parent.getChildPosition(view) == 0)
//            outRect.top = space;
//    }
//}
