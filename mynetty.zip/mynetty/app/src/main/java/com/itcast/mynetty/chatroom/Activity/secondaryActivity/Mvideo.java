package com.itcast.mynetty.chatroom.Activity.secondaryActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Adapter.SpacesItemDecoration;

public class Mvideo extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Mvideo.HomeAdapter adapter;
    private  String [] friendName ={"小红","小白","小蓝","小紫","小红","小绿","小青","小紫","小橙"};
    private  int [] icon={R.mipmap.head,R.mipmap.head1,R.mipmap.head2,R.mipmap.head3,R.mipmap.head4,R.mipmap.head5,R.mipmap.head6,R.mipmap.head7,R.mipmap.head8,R.mipmap.head9};
    private  String []   message={
            " 1.不为往事扰，余生只愿笑。",
            "  2．你是我疲惫生活的希望与糖。",

            " 3．你的恶毒和善良都不够纯粹，所以痛苦。",

            " 4．遍历山河，人间值得。",

            " 5．余凡事喜独出己见，不屑随人是非。",

            " 6．多年后若能重逢，到别来无恙。",

            " 7．世界大雨磅礴，万物苟且而活，无人为你背负更多。",

            " 8．好多喜欢藏在欲言又止里。",

            " 9．我总是感觉很多事情，很多人，都很矛盾。"};

    private  String [] momentsDate={
            "1天前","8天前","8天前","7天前","7天前","4天前","6天前","5天前","3天前","3天前"
    };
    public Mvideo(){

    }
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moments);

        recyclerView =(RecyclerView) findViewById(R.id.momentrv);
        //间隔
        int spacingInPixels = 6;
        recyclerView.addItemDecoration( new SpacesItemDecoration(spacingInPixels));

        recyclerView.setLayoutManager(new LinearLayoutManager(Mvideo.this));
        adapter =new Mvideo.HomeAdapter();
        recyclerView.setAdapter(adapter);




    }



    class  HomeAdapter extends RecyclerView.Adapter<Mvideo.HomeAdapter.MyViewHolder>
    {


        @NonNull
        @Override
        public Mvideo.HomeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Mvideo.HomeAdapter.MyViewHolder holder = new Mvideo.HomeAdapter.MyViewHolder(LayoutInflater.from(Mvideo.this).inflate(R.layout.moments_item,parent,false));

            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull Mvideo.HomeAdapter.MyViewHolder holder, final int position) {

            holder.friendName.setText(friendName[position]);
            holder.messageImage.setBackgroundResource(icon[position]);
            holder.friendMessage.setText(message[position]);
            holder.momentsDate.setText(momentsDate[position]);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }

        @Override
        public int getItemCount() {
            return friendName.length;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView friendName,friendMessage,momentsDate;
            ImageView messageImage;
            public  MyViewHolder(View view)
            {
                super(view);
                friendName =(TextView) view.findViewById(R.id.friendName);
                friendMessage=(TextView)  view.findViewById(R.id.friendMessage);
                messageImage =(ImageView) view.findViewById(R.id.momentImage);
                momentsDate =(TextView)view.findViewById(R.id.momentsDate);
            }






        }
    }
}
