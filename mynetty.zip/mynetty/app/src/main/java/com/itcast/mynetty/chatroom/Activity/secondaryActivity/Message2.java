package com.itcast.mynetty.chatroom.Activity.secondaryActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Adapter.TypeViewAdapter;
import com.itcast.mynetty.chatroom.Entity.MyUser;
import com.itcast.mynetty.chatroom.sqlitelogin.service.PersonService;

/**
 *
 * 2020  5 18
 * @author  weiwei
 * @version  1.0
 */
// 个人信息
public class Message2 extends AppCompatActivity  implements  View.OnClickListener{
//    private static final int RESULT_OK =0 ;
//    private LinearLayout LL01,LL02,LL03;
//    private Context mContext;
//    private ImageButton touxiang;
//    private Bitmap head;// 头像Bitmap
//  //  private static String path = "/sdcard/myHead/";// sd路径
//    private Context context;
//    private RadioGroup radioGroup;
//
//
//     private ImageButton person_view;
//    private Button autograph,myname_btn ,edit_jump;
//    private  TextView txt_content,dialog_person_text;
//    private  int id =1;
//     private  RadioButton male,female;

    private   int userId;
    private RecyclerView preson;

    private static final int ITEM_TYPE_NORMAL= 0;//普通类型
    private static final int ITEM_TYPE_SECTION = 1;//特殊类型
    private  String [] info ={"","昵称","拍一拍","微信号","二维码名片","更多","我的地址"};
    //返回每个数据中的itemType

//    public int getItemViewType(int position) {
//        MyUser goods = mData.get(position);
//        return goods.getViewType();
//    }
    public Message2() {
    }



    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_person2);

        RecyclerView recyclerView = findViewById(R.id.person);

        //2.创建布局管理器-线性布局
        LinearLayoutManager manager = new LinearLayoutManager(this);
        //设置管理器的水平方向，RecyclerView.VERTICAL垂直方向，RecyclerView.HORIZONTAL水平方向
        manager.setOrientation(RecyclerView.VERTICAL);
        //设置布局布局管理器到recyclerView
        recyclerView.setLayoutManager(manager);

        //3.设置数据
        List<MyUser> stringList = new ArrayList<>();
        for (int i = 0; i <7; i++) {
            MyUser myUser = new MyUser();
            myUser.setName(info[i]);
            //每第四个数据为广告类型，其他为普通类型
            myUser.setViewType(i  == 0 ? TypeViewAdapter.ITEM_TYPE_SECTION : TypeViewAdapter.ITEM_TYPE_NORMAL);
            stringList.add(myUser);
        }

        //4.数据适配器
        TypeViewAdapter adapter = new TypeViewAdapter(this, stringList);
        //设置适配器到recyclerView
        recyclerView.setAdapter(adapter);
    }



        @Override
        public void onClick(View v) {


        }
    }


























//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.activity_personal, container, false);
//
//       //昵称
//         txt_content = (TextView) view.findViewById(R.id.myname);
//
//        //签名
//        dialog_person_text = (TextView)view.findViewById(R.id.dialog_autograph_text) ;
//
//
//
//        radioGroup =view.findViewById(R.id.personal_sex);
//        //性别
//        male = (RadioButton)view.findViewById(R.id.male);
//        female = (RadioButton)view.findViewById(R.id.female);
//
//         try {
//             PersonService personService=new PersonService(getActivity());
//            String s = personService.select_person2();
//            if(s!= null)
//            //查询数据库 中的 昵称 并且设置
//            txt_content.setText(s);
//             String autograph_select = personService.select_person3();
//             if (autograph_select != null)
//                 //查询数据库中的 签名
//                 dialog_person_text.setText(autograph_select);
//
//
//             //性别  男 或 女
//
//             String personal_sex = personService.select_person_sex();
//             if (personal_sex != null)
//             {
//
//                 Log.i("TAG", "onCreateView: "+personal_sex);
//                 if (personal_sex .equals("男")) {
//                     male.setChecked(true);
//
//                 }
//                 else
//                     female.setChecked(true);
//
//
//



                 // 用equals 不用  ==


//                 if (personal_sex =="男") {
//                 male.setChecked(true);
//                 female.setChecked(false);
//             }
//             if (personal_sex =="女") {
//                 female.setChecked(true);
//                 male.setChecked(false);
//             }
//         }
//
//
//         }catch (Exception e)
//         {
//             e.printStackTrace();
//         }
//
//        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                PersonService personService=new PersonService(getActivity());
//                switch (checkedId){
//                    case R.id.male:
//                  Toast.makeText(getActivity(),"选择了man",Toast.LENGTH_SHORT).show();
//                  //修改数据库的数据
//                        Log.i("TAG", "onCheckedChanged: "+id);
//                        personService.update_person2(id,"男");
//
//                        break;
//                    case R.id.female:
//                      //  info = rbWoman.getText().toString().trim();
//                        Toast.makeText(getActivity(),"选择了woman",Toast.LENGTH_SHORT).show();
//
//                        personService.update_person2(id,"女");
//                        break;
//                }
//            }
//        });
//
//
//
//
//
//
//
//
//        Log.e("HEHE", "4");
//         //编辑资料
//        edit_jump = view.findViewById(R.id.edit_jump);
//        edit_jump.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//             //   Intent intent=new Intent(getActivity(), Personal3.class);
//            //    startActivity(intent);
//                ++id;
//            }
//        });
//
//       //头像 点击弹出对话框
//        person_view = view.findViewById(R.id.person_view);
//        //签名  点击弹出对话框
//        autograph= view.findViewById(R.id.autograph);
//        // 点击弹出对话框       //姓名
//        myname_btn =view.findViewById(R.id.myname_btn);
//
//        autograph.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//           //    autographDialog();
//
//            }
//        });
//
//        myname_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//           //     myName_btnDialog();
//            }
//        });
//
//
//        return view;
//    }
////String   autograph_1 ;
//    private static final String TAG ="输出  ==========" ;
// //    TextView  autogra1;
//    private void autographDialog() {
//
//        //显示对话框
//        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//        final AlertDialog dialog = builder.create();
//        final View view = View.inflate(getActivity(), R.layout.dialog_select_autograph, null);
//        final EditText autogra1 =view.findViewById(R.id.autogra1);
//        Button off=(Button)view.findViewById(R.id.off);
//        Button ok =(Button)view.findViewById(R.id.ok) ;
//
//
//
//        off.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.dismiss();
//            }
//        });
//        //获取输入内容
//        ok.setOnClickListener(new View.OnClickListener() {
//
//
//            @Override
//            public void onClick(View v) {
//
//
//                String  dialog_autogra =  autogra1.getText().toString().trim();
//                Log.i(TAG, "onClick: "+dialog_autogra);
//
////修改数据库 表person 的 autograph 的数据
//                PersonService personService=new PersonService(getActivity());
//                personService.update_person_autograph(id,dialog_autogra);
//
//                Toast.makeText(getActivity(), "提交成功， 并修改完成", Toast.LENGTH_LONG).show();
//                Toast.makeText(getActivity(), "提交成功", Toast.LENGTH_LONG).show();
//
//                dialog_person_text.setText(dialog_autogra);
//                dialog.dismiss();
//            }
//        });
//        dialog.setView(view);
//        dialog.show();
//
//    }
//    String name;
//    //个人昵称   对话框
//    private  void myName_btnDialog()
//    {
//
//        //显示对话框
//        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//        final AlertDialog dialog = builder.create();
//        final View view = View.inflate(getActivity(), R.layout.dialog_select_name, null);
//     //   final TextView txt_content=view.findViewById(R.id.txt_content);
//        final EditText dialog_name =view.findViewById(R.id.dialog_name);
//        Button cancel=(Button)view.findViewById(R.id.dialog_cancel);
//        Button dialog_ok =(Button)view.findViewById(R.id.dialog_ok) ;
//        cancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.dismiss();
//            }
//        });
//        //获取输入内容
//        dialog_ok.setOnClickListener(new View.OnClickListener() {
//
//
//            @Override
//            public void onClick(View v) {
//
//
//                 name = dialog_name.getText().toString().trim();
//                Log.i(TAG, "onClick: "+name);
//
//                PersonService personService=new PersonService(getActivity());
//                personService.update_person(id,name);
//
//                Toast.makeText(getActivity(), "提交成功， 并修改完成", Toast.LENGTH_LONG).show();
//                dialog.dismiss();
//                //设置 修改  昵称
//                txt_content.setText(name);
//            }
//        });
//        dialog.setView(view);
//        dialog.show();
//        Log.i(TAG, "myName_btnDialog: "+name);
//
//    }
//
//
//
//
//
//
//
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        this.mContext = getActivity();
//    }
//    @Override
//    public void onActivityCreated(Bundle savedInstanceState) {
//        super.onActivityCreated(savedInstanceState);
//        initView();
//
//        /*
//        点击头像进行更换头像
//         */
//        person_view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                switch (v.getId()) {
//                    case R.id.person_view:// 更换头像
//                        showTypeDialog();
//                        break;
//                }
//            }
//        });
//
//    }
//    private void initView() {
//
////        Bitmap bt = BitmapFactory.decodeFile( "head.jpg");// 从SD卡中找头像，转换成Bitmap
////        if (bt != null) {
////            @SuppressWarnings("deprecation")
////            Drawable drawable = new BitmapDrawable(bt);// 转换成drawable
////            person_view.setImageDrawable(drawable);
////        } else {
////            /**
////             * 没有服务器         为空
////             * 如果SD里面没有则需要从服务器取头像，取回来的头像再保存在SD中
////             *
////             */
////        }
//    }
//
//    //头像
////
////   int RC_CHOOSE_PHOTO=1 ;
//////    int RC_TAKE_PHOTO=0;
////    @Override
////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
////        switch (requestCode) {
//////            case RC_TAKE_PHOTO:   //拍照权限申请返回
//////                if (grantResults.length == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//////                  //  takePhoto();
//////                }
//////                break;
//////            case RC_CHOOSE_PHOTO:   //相册选择照片权限申请返回
//////                 choosePhoto();
//////                break;
////        }
////    }
//
//    private void choosePhoto() {
//    }
//
//    private void showTypeDialog() {
//        //显示对话框
//        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
//        final AlertDialog dialog = builder.create();
//        View view = View.inflate(getActivity(), R.layout.dialog_select_photo, null);
//        TextView tv_select_gallery = (TextView) view.findViewById(R.id.tv_select_gallery);
//        TextView tv_select_camera = (TextView) view.findViewById(R.id.tv_select_camera);
//        tv_select_gallery.setOnClickListener(new View.OnClickListener() {// 在相册中选取
//            @Override
//            public void onClick(View v) {
////                if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
////                    //未授权，申请授权(从相册选择图片需要读取存储卡的权限)
////                 //   ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, RC_CHOOSE_PHOTO);
////                } else {
//                    //已授权，获取照片
//
//
////                Intent intent1 = new Intent(Intent.ACTION_PICK, null);
////                //打开文件
////                intent1.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
////                Log.i(TAG, "onClick: 打开文件");
////                getActivity().startActivityForResult(intent1, 1);
//
//
//                Intent intent = new Intent("android.intent.action.GET_CONTENT");
//                intent.setType("image/*");
//                getActivity().startActivityForResult(intent,1);
//             //   }
//              //  person_view.setImageResource(R.drawable.forest);// 用ImageButton显示出来
//                dialog.dismiss();
//            }
//        });
//        tv_select_camera.setOnClickListener(new View.OnClickListener() {// 调用照相机
//            @Override
//            public void onClick(View v) {
//                Intent intent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                intent2.putExtra(MediaStore.EXTRA_OUTPUT,
//                        Uri.fromFile(new File(Environment.getExternalStorageDirectory(), "head.jpg")));
//                getActivity().startActivityForResult(intent2, 2);// 采用ForResult打开
//                dialog.dismiss();
//            }
//        });
//        dialog.setView(view);
//        dialog.show();
//    }
//
//    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        Log.i(TAG, "onActivityResult:  裁剪图片");
//        switch (requestCode) {
//            case 1:
//
//
//                if (resultCode == RESULT_OK&&data!=null){
//                    Log.i(TAG, "onActivityResult:   dsss");
//                    if (Build.VERSION.SDK_INT>=19)
//                        handImage(data);
//
//                    else handImageLow(data);
//                }
//
////                if (resultCode == RESULT_OK  && data!=null) {
////                    cropPhoto(data.getData());// 裁剪图片
////
////                    Log.i(TAG, "onActivityResult:  裁剪图片");
//
//
////                String path = null;
////                Uri uri = data.getData();
//////                //根据不同的uri进行不同的解析
////                if (DocumentsContract.isDocumentUri(getActivity(), uri)) {
////                    String docId = DocumentsContract.getDocumentId(uri);
////                    if ("com.android.providers.media.documents".equals(uri.getAuthority())) {
////                        String id = docId.split(":")[1];
////                        String selection = MediaStore.Images.Media._ID + "=" + id;
////                        path = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, selection);
////                    } else
////
////                        //if ("com.android.providers.downloads.documents".equals(uri.getAuthority())) {
//////                       Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(docId));
//////                        path = getImagePath(contentUri, null);
//////                    }
//////                } else if ("content".equalsIgnoreCase(uri.getScheme())) {
//////                    path = getImagePath(uri, null);
//////                } else if ("file".equalsIgnoreCase(uri.getScheme())) {
//////                    path = uri.getPath();
//////
//////
//////                    displayImage(path);
//////
//////
//////                }
////
////                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
////                            uri = ContentUris.withAppendedId(uri.parse("content://downloads/public_downloads"), Long.valueOf(docId));
////                            path = getImagePath(uri, null);
////                        } else {
////                            String name = null;
////                            Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
////                            if (cursor != null) {
////                                if (cursor.moveToFirst()) {
////                                    name = cursor.getString(2);
////                                }
////                                cursor.close();
////                            }
////                            File file = new File(Environment.getExternalStorageDirectory(), "/Download/" + name);
////                            path = file.getPath();
////
////                        }
////                        if ("content".equalsIgnoreCase(uri.getScheme())) {
////                    path = getImagePath(uri, null);
////                } else if ("file".equalsIgnoreCase(uri.getScheme())) {
////                    path = uri.getPath();
////
////
////                    displayImage(path);
////
////
////                }
////                  //  displayImage(path);
////                }
//
//
//                break;
//            case 2:
//                if (resultCode == RESULT_OK) {
//                  //  File temp = new File(Environment.getExternalStorageDirectory() + "/head.jpg");
//                  //  cropPhoto(Uri.fromFile(temp));// 裁剪图片
//                }
//
//                break;
//            case 3:
//                if (data != null) {
//                    Bundle extras = data.getExtras();
//                    head = extras.getParcelable("data");
//                    if (head != null) {
//                        /**
//                         * 上传服务器代码
//                         */
//                      setPicToView(head);// 保存在SD卡中
//
//
//                        Log.i(TAG, "onActivityResult:  显示图片                  哈哈");
//                        person_view.setImageResource(R.mipmap.iv_lol_icon3);// 用ImageButton显示出来
//                    }
//                }
//                break;
//            default:
//                break;
//
//        }
//        super.onActivityResult(requestCode, resultCode, data);
//    }
//
//    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
//    private void handImage(Intent data) {
//
//        String path =null;
//        Uri uri = data.getData();
//        //根据不同的uri进行不同的解析
//        if (DocumentsContract.isDocumentUri(getActivity(),uri)){
//            String docId = DocumentsContract.getDocumentId(uri);
//            if ("com.android.providers.media.documents".equals(uri.getAuthority())){
//                String id = docId.split(":")[1];
//                String selection = MediaStore.Images.Media._ID+"="+id;
//                path = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,selection);
//            }else if("com.android.providers.downloads.documents".equals(uri.getAuthority())){
//                Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"),Long.valueOf(docId));
//                path = getImagePath(contentUri,null);
//            }
//        }else if ("content".equalsIgnoreCase(uri.getScheme())){
//            path = getImagePath(uri,null);
//        }else if ("file".equalsIgnoreCase(uri.getScheme())){
//            path = uri.getPath();
//        }
//        //展示图片
//        displayImage(path);
//    }
//
//
//    private void handImageLow(Intent data){
//        Uri uri = data.getData();
//        String path = getImagePath(uri,null);
//        displayImage(path);
//    }
//
//
//
//
//
//
//    private String getImagePath(Uri uri,String selection) {
//        String path = null;
//        Cursor cursor = getActivity().getContentResolver().query(uri,null,selection,null,null);
//        if (cursor!=null){
//            if (cursor.moveToFirst()){
//                path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
//            }
//            cursor.close();
//        }
//        return path;
//    }
//
//    private void displayImage(String imagePath){
//        Log.i(TAG, "displayImage:     设置");
//        if (imagePath != null){
//            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
//            person_view.setImageBitmap(bitmap);
//        }else{
//            Toast.makeText(getActivity(),"fail to set image",Toast.LENGTH_SHORT).show();
//        }
//    }
//
//
//
//
//    /**
//     * 调用系统的裁剪功能
//     *
//     * @param uri
//     */
//    public void cropPhoto(Uri uri) {
//
//
//        if (uri == null) {
//            Log.i("tag", "The uri is not exist.");
//        }
//        Intent intent = new Intent("com.android.camera.action.CROP");
//        intent.setDataAndType(uri, "image/*");
//        intent.putExtra("crop", "true");
//        // aspectX aspectY 是宽高的比例
//        intent.putExtra("aspectX", 1);
//        intent.putExtra("aspectY", 1);
//        // outputX outputY 是裁剪图片宽高
//        intent.putExtra("outputX", 150);
//        intent.putExtra("outputY", 150);
//        intent.putExtra("return-data", true);
//        getActivity().startActivityForResult(intent, 3);
//
//
//        Log.i(TAG, "cropPhoto:   实现裁 剪    并跳转");
//    }
//
//    private void setPicToView(Bitmap mBitmap) {
//     //   String sdStatus = Environment.getExternalStorageState();
////        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { // 检测sd是否可用
////            return;
////        }
//        FileOutputStream b = null;
//        //File file = new File("data/cache/backup");
//       // file.mkdirs();// 创建文件夹
//        String fileName =   "head.jpg";// 图片名字
//        try {
//            b = new FileOutputStream(fileName);
//            mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, b);// 把数据写入文件
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                // 关闭流
//                b.flush();
//                b.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//  }

//}
