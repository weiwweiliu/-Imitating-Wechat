package com.itcast.mynetty.chatroom.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.listview.ViewHolder;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * 2020  5 19
 * @author  weiwei
 * @version  1.0
 */
@RequiresApi(api = Build.VERSION_CODES.KITKAT)
public class News extends Fragment  implements   AbsListView.OnScrollListener {
    private static final String TAG = "输出";
 //   private ImageView ivDeleteText;
 //   private EditText etSearch;


    private final String[] name = new String[] { "聊天室1", "聊天室2", "谭咏麟","王菲", "梁朝伟", "谭咏麟","张国荣", "张学友", "谭咏麟","张国荣", "张学友", "谭咏麟" };
    private  String [] date ={"2020 11 2", "2020 3 9","2020 6 4","上午 3：7","下午11：2","昨天","昨天", "昨天","昨天","昨天","昨天","昨天"};
    private final String[] message = new String[] {
            "张学友，歌手、演员，1961年7月10日出生于香港，1984年获得香港首届十八区业余歌唱大赛冠军，正式出道，1993年发行的国语唱片《吻别》年度销量超过400万张，1995年、1996年连续两年获得世界音乐大奖全球销量最高亚洲流行乐歌手奖",
            "谭咏麟，1950年8月23日出生于香港，籍贯广东新会，中国香港男歌手、音乐人、演员。[1]20世纪60年代末为Loosers乐队成员。1973年任温拿乐队主音歌手。1975年参演首部电影《大家乐》。1978年温拿乐队宣布解散，谭咏麟以个人身份发展。1979年赴台湾发展事业，推出首张个人专辑《反斗星》",
            "王菲（Faye Wong），原名夏林，曾用名王靖雯，1969年8月8日出生于北京，中国流行乐女歌手、影视演员  ，中国国家一级演员  。\n" +
                    "1989年，凭借歌曲《仍是旧句子》在香港歌坛出道   ，同年发行首张个人专辑《王靖雯》  。1992年，因演唱歌曲《容易受伤的女人》而被听众所熟知。1993年，在专辑《十万个为什么？》 中尝试另类音乐的风格   " +
                    "。1994年，发行专辑《天空》，并获得十大劲歌金曲最受欢迎女歌星奖；同年在香港红磡体育馆举办18场“最精彩演唱会”，打破中国香港歌手初次开演唱会的场次纪录   。" +
                    "1996年，成为首位登上美国《时代周刊》封面的华人歌手  。",

            "张国荣（1956年9月12日-2003年4月1日），出生于香港，中国香港男歌手、演员、音乐人，影视歌多栖发展的代表之一。\n" +
                    "1977年正式出道。1983年以《风继续吹》成名。1984年演唱的《Monica》是香港歌坛第一支同获十大中文金曲、十大劲歌金曲的舞曲。1986年、1987年获劲歌金曲金奖；" +
                    "之后凭借专辑《爱慕》《The Greatest Hits of Leslie Cheung》成为首位打入韩国音乐市场的粤语歌手 [1]  ，并打破华语唱片在韩国的销量纪录 [2-4]  。" +
                    "1988年、1989年获十大劲歌金曲最受欢迎男歌星奖。1999年获香港乐坛最高荣誉金针奖。2000年获CCTV-MTV音乐盛典亚洲最杰出艺人奖 [5]  。" +
                    "2010年入选美国CNN评出的“过去50年里全球最知名的20位歌手/乐团” [6]  。他擅长词曲创作，担任过MV导演、唱片监制、演唱会艺术总监等。",

            " 梁朝伟，1962年6月27日出生于中国香港，祖籍广东省台山市，中国香港男演员、歌手，国家一级演员，毕业于香港无线训练班第11期。"};
    private final   String [] myName ={"小黑","小白","小蓝","小紫","小红","小绿","小青","小紫","小橙","昨天","前天","昨天","前天"};
    private final   int [] photo ={R.mipmap.head,R.mipmap.head1,R.mipmap.head2,R.mipmap.head3,R.mipmap.head4,R.mipmap.head5,R.mipmap.head6,R.mipmap.head7,R.mipmap.head8,R.mipmap.head9,R.mipmap.head10,R.mipmap.head11};
    private listViewAdapter adapter = new listViewAdapter();
    private ListView listView;
    private LinearLayout loadingLayout;
    private Thread mThread;
    private Context mContext;
    private boolean[] checkItems;
    private AlertDialog alert = null;
    private AlertDialog.Builder builder = null;
    private  int pos;
    /**
     * 设置布局显示属性
     */
    private LayoutParams mLayoutParams = new LayoutParams(
            LayoutParams.WRAP_CONTENT,
            LayoutParams.WRAP_CONTENT);
    /**
     * 设置布局显示目标最大化属性
     */
    private LayoutParams FFlayoutParams = new LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT);

    private ProgressBar progressBar;

    /** Called when the activity is first created. */




    public News() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_first, container, false);
       // TextView txt_content = (TextView) view.findViewById(R.id.myname);
       // txt_content.setText("无终");
        Log.e("HEHE", "2");

//        ivDeleteText = (ImageView) view.findViewById(R.id.ivDeleteText);
//        etSearch = (EditText) view.findViewById(R.id.etSearch);

        //搜索框
//        ivDeleteText.setOnClickListener(new View.OnClickListener() {
//
//            public void onClick(View v) {
//                etSearch.setText("");
//            }
//        });
//
//        etSearch.addTextChangedListener(new TextWatcher() {
//
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                // TODO Auto-generated method stub
//
//            }
//
//            public void beforeTextChanged(CharSequence s, int start, int count,
//                                          int after) {
//                // TODO Auto-generated method stub
//
//            }
//
//            public void afterTextChanged(Editable s) {
//                if (s.length() == 0) {
//                    ivDeleteText.setVisibility(View.GONE);
//                } else {
//                    ivDeleteText.setVisibility(View.VISIBLE);
//                }
//            }
//        });
        // 得到一个ListView用来显示条目
        listView = (ListView) view.findViewById(android.R.id.list);
        Log.i(TAG, "onCreateView: "+listView);

        init2();




        return view;
    }



    private void init2() {
        // TODO Auto-generated method stub
        // 线性布局
        LinearLayout layout = new LinearLayout(getActivity());
        // 设置布局 水平方向
        layout.setOrientation(LinearLayout.HORIZONTAL);
        // 进度条
        progressBar = new ProgressBar(getActivity());
        // 进度条显示位置
        progressBar.setPadding(0, 0, 15, 0);
        // 把进度条加入到layout中
        layout.addView(progressBar, mLayoutParams);
        // 文本内容
        TextView textView = new TextView(getActivity());
        textView.setText("拼命加载中...");
        textView.setGravity(Gravity.CENTER_VERTICAL);
        // 把文本加入到layout中
        layout.addView(textView, FFlayoutParams);
        // 设置layout的重力方向，即对齐方式是
        layout.setGravity(Gravity.CENTER);

        // 设置ListView的页脚layout
        loadingLayout = new LinearLayout(getActivity());
        loadingLayout.addView(layout, mLayoutParams);
        loadingLayout.setGravity(Gravity.CENTER);

        // 添加到脚页显示
        listView.addFooterView(loadingLayout);
        // 给ListView添加适配器
        listView.setAdapter(adapter);
        // 给ListView注册滚动监听
        listView.setOnScrollListener(this);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            //arg2 视图在adapter的位置， arg3 点击元素的行id
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) {


                Bundle bundle = new Bundle();
                bundle.putInt("photo", photo[arg2]);
                bundle.putString("message", message[arg2]);
                bundle.putString("name", myName[arg2]);
                Intent intent = new Intent();
                intent.putExtras(bundle);
                intent.setClass(requireActivity(), ChatRoom.class);
                Log.i("message", message[arg2]);
                startActivity(intent);
            }
        });
    }




    /**
     * 要用用于生成显示数据
     *
     *
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    class listViewAdapter extends BaseAdapter {

        private Context context;

        private LayoutInflater inflater;

        public ArrayList<String> arr;

        public listViewAdapter(Context context) {

            super();

            this.context = context;

            inflater = LayoutInflater.from(context);

            arr = new ArrayList<String>();

            for(int i=0;i<3;i++){    //listview初始化3个子项

                arr.add("王3");
                arr.add("王1");
                arr.add("王2");

            }

        }

        public listViewAdapter() {

        }

//        public listViewAdapter(ArrayList<String> list) {
//            this.list = list;
//        }

        int count = name.length/2;
        //     int count = Objects.requireNonNull(arr).size()/2;
//
//        public listViewAdapter() {
//
//        }
//item总数
        public int getCount() {
            return count;
            //    return arr.size();

        }

        //item 的数据对象
        public Object getItem(int pos) {
//            return pos;
            return   pos;
        }

        //item 的id
        public long getItemId(int pos) {
            return pos;
        }

        //item的View视图
        public View getView(final int pos, View v, ViewGroup p) {

            ViewHolder holder=null;

            if (v == null)
            {
                v = View.inflate(getActivity(),R.layout.listview_item,null);
                holder =new ViewHolder();
                holder.title = (TextView) v.findViewById(R.id.mytitle);
                holder.explanation = (TextView) v.findViewById(R.id.explanation);
                holder.list_iv =(ImageView) v.findViewById(R.id.list_iv);
                holder.date=(TextView) v.findViewById(R.id.date);
            //    holder.list_btn =(Button) v.findViewById(R.id.list_btn);

                v.setTag(holder);
            }else {
                holder =(ViewHolder) v.getTag();
            }



            holder.title.setText(name[pos]);
            holder.date.setText(date[pos]);
            holder.explanation.setText(myName[pos]);
            holder.list_iv.setBackgroundResource(photo[pos]);
            return v;
        }




//        public  void  deleteDialog(final int pos){
//            mContext = getActivity();
//            final String[] fruits = new String[]{"不感兴趣", "内容太老了", "拉黑作者", "减少推荐"};
//            alert = null;
//            builder = new AlertDialog.Builder(mContext);
//            //           final List<ViewHolder> holder = null;
////            final List<ViewHolder> finalHolders = holder;
//            alert = builder.setIcon(R.mipmap.ic_launcher)
//                    .setTitle("确定删除这条信息~")
//                    .setSingleChoiceItems(fruits, 0, new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            Toast.makeText(getActivity().getApplicationContext(), "你选择了" + fruits[which], Toast.LENGTH_SHORT).show();
//
//                            switch (which) {
//                                case  0:
//                                    System.out.println(pos);
//
//
//
//
//
//                                    adapter.notifyDataSetChanged();
//                                    alert.dismiss();
//                                    break;
//                                case  1:
//
//                                    break;
//                                default:
//                                    break;
//                            }
//                        }
//                    }).create();
//            alert.show();
//        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem,
                         int visibleItemCount, int totalItemCount) {
        // TODO Auto-generated method stub
        if(firstVisibleItem+visibleItemCount==totalItemCount)
        {
            //开线程去下载网络数据
            if (mThread == null || !mThread.isAlive()) {
                mThread = new Thread() {
                    @Override
                    public void run() {
                        try {
                            //这里放你网络数据请求的方法，我在这里用线程休眠5秒方法来处理
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                    }
                };
                mThread.start();
            }
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        // TODO Auto-generated method stub
    }

    private Handler handler = new Handler() {
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            switch (msg.what) {
                case 1:
                    if (adapter.count <= name.length-1) {
                        //    adapter.arr    += 6;
                        adapter.count +=6;
                        int currentPage = adapter.count / 6;
                        Toast.makeText(getActivity().getApplicationContext(),"第" + currentPage + "页", Toast.LENGTH_LONG).show();
                    } else {
                        listView.removeFooterView(loadingLayout);
                    }
                    //重新刷新Listview的adapter里面数据
                    adapter.notifyDataSetChanged();
                    break;
                default:
                    break;
            }
        }

    };




}
