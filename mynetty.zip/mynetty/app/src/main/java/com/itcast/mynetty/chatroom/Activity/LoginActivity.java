package com.itcast.mynetty.chatroom.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

;
import com.itcast.mynetty.R;


import com.itcast.mynetty.chatroom.sqlitelogin.service.UserService;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViews();
    }
    private EditText username;
    private EditText password;
    private Button login;
    private Button register;
    private  String key="Result";

    private void findViews() {
        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        login=(Button) findViewById(R.id.login);
        register=(Button) findViewById(R.id.register);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=username.getText().toString();
                System.out.println(name);
                String pass=password.getText().toString();
                System.out.println(pass);
                System.out.println("****************************************");
                Log.i("TAG",name+"_"+pass);
                UserService uService=new UserService(LoginActivity.this);
                boolean flag=uService.login(name, pass);
                System.out.println("==============================================");

//                Intent intent = new Intent(LoginActivity.this, AppStart.class);
               Bundle bundleSimple = new Bundle();

                Intent intent = new Intent();

                //返回码
                int resultCode1 = 1;
                setResult(resultCode1, intent);
                if(flag){
                    System.out.println("--------------获取成功-----------------------");
                    Log.i("TAG","登录成功");
                    Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_LONG).show();

//
//                    bundleSimple.putBoolean("First", true);
//                    intent.putExtras(bundleSimple);
//                    startActivity(intent);


                    intent.setClass(LoginActivity.this, Index.class);

                    startActivity(intent);
                    //返回数据回调到appstart
//                    Intent intent2=new Intent();
////                    intent.putExtras(bundle);
//                    intent2.putExtra(key, "login登录成功");
//                    setResult(resultCode1, intent2);
//
//
//                    Intent i = new Intent();
//                    i.putExtra("result", "登录成功");
//                    setResult(3, i);
//                    finish();
               //    int RESULT_OK=1;
                 //   setResult(RESULT_OK, new Intent().putExtra("s", "哈哈哈"));
                    finish();

                }else{
                    Log.i("TAG","登录失败");
                    Toast.makeText(LoginActivity.this, "登录失败", Toast.LENGTH_LONG).show();
//                    bundleSimple.putBoolean("First", false);
//                    intent.putExtras(bundleSimple);
//                    startActivity(intent);
                //    intent.setClass(LoginActivity.this, ChatRoom.class);
                 //   finish();
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent=new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
