package com.itcast.mynetty.chatroom.Activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.MyFragmentPagerAdapter;
import com.itcast.mynetty.chatroom.myDialog.CommonDialog;


@RequiresApi(api = Build.VERSION_CODES.KITKAT)
/**
 *
 * 2020  5 16
 * @author  weiwei
 * @version  1.0
 */


// 主页   里面 有四个view
public class Index extends AppCompatActivity  implements RadioGroup.OnCheckedChangeListener,
        ViewPager.OnPageChangeListener {


    //UI Objects
    private TextView txt_topbar;
    private RadioGroup rg_tab_bar;
    private RadioButton rb_channel;
    private RadioButton rb_message;
    private RadioButton rb_better;
    private RadioButton rb_setting;
    private ViewPager vpager;

    private MyFragmentPagerAdapter mAdapter;

    //几个代表页面的常量
    public static final int PAGE_ONE = 0;
    public static final int PAGE_TWO = 1;
    public static final int PAGE_THREE = 2;
    public static final int PAGE_FOUR = 3;







    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);

       // mAdapter = new MyFragmentPagerAdapter(getSupportFragmentManager());
        mAdapter =new MyFragmentPagerAdapter(getSupportFragmentManager());

        bindViews();
        rb_channel.setChecked(true);



        //   从个人资料编辑传来d值
        Intent intent = getIntent();
        int id = intent.getIntExtra("id", 1);
        if (id==4)
        {
            vpager.setCurrentItem(PAGE_FOUR);
        }







    }


    //返回弹出对话框
    @Override
    public void onBackPressed() {

        init();
    }


    private void init() {


        final CommonDialog dialog = new CommonDialog(Index.this);
        dialog.setTitle("");
        dialog.setMessage("确定退出吗？");
        dialog.setNegtive("再看看");
        dialog.setPostitive("说走就走");
        dialog.setOnClickBottomListener( new CommonDialog.OnClickButtomListener(){
            @Override
            public void onPositiveClick() {

                dialog.dismiss();
//CloseActivity closeActivity =new CloseActivity();
//closeActivity.close();
                finish();
            }

            @Override
            public void onNegtiveClick() {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    private void bindViews() {
        txt_topbar = (TextView) findViewById(R.id.txt_topbar);
        rg_tab_bar = (RadioGroup) findViewById(R.id.rg_tab_bar);
        rb_channel = (RadioButton) findViewById(R.id.rb_channel);
        rb_message = (RadioButton) findViewById(R.id.rb_message);
        rb_better = (RadioButton) findViewById(R.id.rb_better);
        rb_setting = (RadioButton) findViewById(R.id.rb_setting);
        rg_tab_bar.setOnCheckedChangeListener(this);

        vpager = (ViewPager) findViewById(R.id.vpager);
        vpager.setAdapter(mAdapter);
        vpager.setCurrentItem(0);
        vpager.addOnPageChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.rb_channel:
                txt_topbar.setText("微信");
                vpager.setCurrentItem(PAGE_ONE);
                break;
            case R.id.rb_message:
                txt_topbar.setText("联系人");
                vpager.setCurrentItem(PAGE_TWO);
                break;
            case R.id.rb_better:
                txt_topbar.setText("看一看");
                vpager.setCurrentItem(PAGE_THREE);
                break;
            case R.id.rb_setting:
                txt_topbar.setText("我");
                vpager.setCurrentItem(PAGE_FOUR);
                break;
        }
    }


    //重写ViewPager页面切换的处理方法
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
    }

    @Override
    public void onPageScrollStateChanged(int state) {
        //state的状态有三个，0表示什么都没做，1正在滑动，2滑动完毕
        if (state == 2) {
            switch (vpager.getCurrentItem()) {
                case PAGE_ONE:
                    rb_channel.setChecked(true);
                    break;
                case PAGE_TWO:
                    rb_message.setChecked(true);
                    break;
                case PAGE_THREE:
                    rb_better.setChecked(true);
                    break;
                case PAGE_FOUR:
                    rb_setting.setChecked(true);
                    break;
            }
        }
    }


}


