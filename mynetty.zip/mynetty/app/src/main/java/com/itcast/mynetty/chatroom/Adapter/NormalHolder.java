package com.itcast.mynetty.chatroom.Adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import  com.itcast.mynetty.R;
//普通类型ViewHolder
public class NormalHolder extends RecyclerView.ViewHolder {
    ImageView mIv_head;
    TextView mTv_name;

    NormalHolder(@NonNull View itemView) {
        super(itemView);
    //    mIv_head = itemView.findViewById(R.id.iv_head);
        mTv_name = itemView.findViewById(R.id.tv_name);
    }
}