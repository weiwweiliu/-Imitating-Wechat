package com.itcast.mynetty.chatroom.myDialog;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.itcast.mynetty.R;


/**
 *
 * 2020  5 03
 * @author  weiwei
 * @version  1.0
 */


//  自定义 对话框  用于退出
public class CommonDialog extends AlertDialog {

    private TextView titleTV,messageTV;
    private Button negtivebtn,positivebtn;

    private  String  message,title,positive2,negtive2;

    public CommonDialog(Context context){
        super(context);

    }
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.custom_dialog);
        initView();
        initEvent();
    }

    private void initEvent() {
        positivebtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (onClickButtomListener !=null)
                    onClickButtomListener.onPositiveClick();
            }
        });

        negtivebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickButtomListener !=null)
                {
                    onClickButtomListener.onNegtiveClick();
                }
            }
        });
    }

    private void initView() {
        negtivebtn =(Button) findViewById(R.id.negtive);
        positivebtn =(Button) findViewById(R.id.positive);
        titleTV =(TextView) findViewById(R.id.titleTV);
        messageTV =(TextView) findViewById(R.id.message);

    }
    private  void  refreshView()
    {
        if (!TextUtils.isEmpty(title)){
            titleTV.setText(title);
            titleTV.setVisibility(View.VISIBLE);
        }else {
            titleTV.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(message))
        {
            messageTV.setText(message);
        }
        if (!TextUtils.isEmpty(positive2))
    {
        positivebtn.setText(positive2);
    }else {
        positivebtn.setText("确定");

    }
        if (!TextUtils.isEmpty(negtive2))
        {
            negtivebtn.setText(negtive2);
        }else {
            negtivebtn.setText("取消");

        }
    }


    public  void show()
    {
        super.show();
        refreshView();
    }
    public  interface  OnClickButtomListener{
        void  onPositiveClick();
        void  onNegtiveClick();
    }
    public  OnClickButtomListener onClickButtomListener;
    public  CommonDialog setOnClickBottomListener(OnClickButtomListener onClickButtomListener)
    {
        this.onClickButtomListener = onClickButtomListener;
        return this;
    }
    public  CommonDialog setMessage(String message)
    {
        this.message=message;
        return  this;
    }
    public  CommonDialog setTitle(String title)
    {
        this.title=title;
        return  this;
    }
    public  CommonDialog setPostitive(String positive2)
    {
        this.positive2=positive2;
        return this;
    }
    public  CommonDialog setNegtive(String negtive2)
    {
        this.negtive2=negtive2;
        return  this;
    }
}
