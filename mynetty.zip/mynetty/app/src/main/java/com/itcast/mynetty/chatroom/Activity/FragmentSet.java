package com.itcast.mynetty.chatroom.Activity;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Activity.secondaryActivity.Moments;
import com.itcast.mynetty.chatroom.Activity.secondaryActivity.Mvideo;
import com.itcast.mynetty.chatroom.Activity.secondaryActivity.Shake;
import com.itcast.mynetty.chatroom.Adapter.SpacesItemDecoration;

import java.util.Objects;

/**
 *
 * 2020  5 17
 * @author  weiwei
 * @version  1.0
 */

//第3 个 view     发现页面
    //使用RecyclerView
public  class FragmentSet extends Fragment {

    private RecyclerView recyclerView;
    private HomeAdapter adapter;
        private  String [] title ={"朋友圈","视频号","扫一扫","摇一摇","看一看","搜一搜","附件的人","购物","游戏"};
        private  int [] icon={R.mipmap.friends,R.mipmap.video,R.mipmap.scan,R.mipmap.shake,R.mipmap.see,R.mipmap.search,
                R.mipmap.nearby,R.mipmap.shop,R.mipmap.game};
    public FragmentSet() {


    }
//初始化页面
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_set, container, false);
        Log.e("HEHE", "第三个");
    //view.findViewById(R.drawable.blue)
        recyclerView =(RecyclerView) view.findViewById(R.id.mrecyler);
        int spacingInPixels = 8;
        recyclerView.addItemDecoration( new SpacesItemDecoration(spacingInPixels));

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter =new HomeAdapter();
        recyclerView.setAdapter(adapter);



        return view;
    }
    class  HomeAdapter extends RecyclerView.Adapter<HomeAdapter.MyViewHolder>
    {


        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MyViewHolder holder = new MyViewHolder(getLayoutInflater().from(getActivity()).inflate(R.layout.recycler_item,parent,false));

            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

           holder.rl_title.setText(title[position]);
           holder.imageView.setBackgroundResource(icon[position]);


           holder.itemView.setOnClickListener(new View.OnClickListener() {
               @RequiresApi(api = Build.VERSION_CODES.KITKAT)
               @Override
               public void onClick(View v) {
                   Bundle bundle = new Bundle();
                   Intent intent = new Intent();
                   switch (position)
                   {
                       case 0:

                           Log.i("-------", "朋友圈: item0");
                           bundle.putString("name", title[position]);

                           intent.putExtras(bundle);
                           intent.setClass(requireActivity(), Moments.class);
                           startActivity(intent);
                           break;
                       case 1:

                           bundle.putString("video", title[position]);
                           intent.putExtras(bundle);
                           intent.setClass(Objects.requireNonNull(getActivity()), Mvideo.class);
                           startActivity(intent);
                           Log.i("-------", "视频号: item1");
                           break;
                       case 2:
                           Log.i("-------", "扫一扫: item2");
                           break;
                       case 3:

                           bundle.putString("shake", title[position]);
                           intent.putExtras(bundle);
                           intent.setClass(Objects.requireNonNull(getActivity()), Shake.class);
                           startActivity(intent);
                           Log.i("-------", "摇一摇: item3");
                           break;
                   }
               }
           });
        }

        @Override
        public int getItemCount() {
            return title.length;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView rl_title;
            ImageView imageView;
            public  MyViewHolder(View view)
            {
                super(view);
                rl_title =(TextView) view.findViewById(R.id.rl_name);
                imageView =(ImageView)view.findViewById(R.id.rl_iv);
            }






            }
        }
    }











