package com.itcast.mynetty.chatroom.sqlitelogin.test;

import java.io.Serializable;

public class Person implements Serializable

    {
        private int id;
        private String name;
        private String autograph;

        private String sex;
    public Person() {
        super();
        // TODO Auto-generated constructor stub
    }

        public Person(int id, String name, String autograph, String sex) {
            this.id = id;
            this.name = name;
            this.autograph = autograph;
            this.sex = sex;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAutograph() {
            return autograph;
        }

        public void setAutograph(String autograph) {
            this.autograph = autograph;
        }

        public String getSex() {
            return sex;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", autograph='" + autograph + '\'' +
                    ", sex='" + sex + '\'' +
                    '}';
        }
    }
