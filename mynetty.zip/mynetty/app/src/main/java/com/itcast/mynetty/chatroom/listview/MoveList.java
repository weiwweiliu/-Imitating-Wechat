package com.itcast.mynetty.chatroom.listview;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.itcast.mynetty.R;

/**
 *
 * 2020  5 16
 * @author  weiwei
 * @version  1.0
 */
//item  跳转的类
public class MoveList extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.model);

        Bundle bundle=getIntent().getExtras();
        int id=bundle.getInt("photo");
        String message=bundle.getString("message");
        String size=bundle.getString("size");
        ImageView Iv=(ImageView) findViewById(R.id.Iv);
        Iv.setImageResource(id);
        TextView tv=(TextView) findViewById(R.id.tv_message);
        tv.setText(message);
        TextView tv2=(TextView) findViewById(R.id.tv_exp);
        tv2.setText(size);

    }

}
