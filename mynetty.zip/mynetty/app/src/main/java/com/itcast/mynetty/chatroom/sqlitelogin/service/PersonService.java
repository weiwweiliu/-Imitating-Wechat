package com.itcast.mynetty.chatroom.sqlitelogin.service;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.itcast.mynetty.chatroom.sqlitelogin.test.Person;


/**
 * 2020  5 19
 *
 * @author weiwei
 * @version 1.0
 */

public class PersonService {
    private static final String TAG ="输出==============" ;
    private DatabaseHelper2 dbHelper;
    public PersonService(Context context){
        dbHelper=new DatabaseHelper2(context);
    }

  public  boolean insert_person(Person person)
  {
      SQLiteDatabase sdb=dbHelper.getReadableDatabase();
      String sql="insert into person(name,autograph,sex) values(?,?,?)";
      Object obj[]={person.getName(),person.getAutograph(),person.getSex()};
      sdb.execSQL(sql, obj);

      Log.i(TAG, "insert_person:  插入成功  录入数据");
      
      sdb.close();
      return true;
  }
    public boolean update_person(int id ,String name){
        SQLiteDatabase sdb=dbHelper.getReadableDatabase();
        String sql="update person set name=?   where id =?";

        sdb.execSQL(sql, new  Object[]{name,id});
        Log.i(TAG, "update_person:  修改成功  昵称更改");
    sdb.close();
        return true;
    }

    public boolean update_person2(int id ,String sex){
        SQLiteDatabase sdb=dbHelper.getReadableDatabase();
        String sql="update person set sex=?   where id =?";

        sdb.execSQL(sql, new  Object[]{sex,id});
        Log.i(TAG, "update_person:  修改成功     性别更改");
        sdb.close();
        return true;
    }





    public boolean update_person_autograph(int id ,String autograph){
        SQLiteDatabase sdb=dbHelper.getReadableDatabase();
        String sql="update person set autograph=?   where id =?";

        sdb.execSQL(sql, new  Object[]{autograph,id});
        Log.i(TAG, "update_person_autograph:  修改成功   签名更改");
        sdb.close();
        return true;
    }

    //根据昵称查找
    public  void  select_person (String  name)
    {
        SQLiteDatabase sdb=dbHelper.getReadableDatabase( );
        String sql="select * from person  where name=?";

        Cursor cursor=sdb.rawQuery(sql,new String [] {name});
        
        // cursor.moveToFirst();
        if(cursor.getCount() !=0) 
        {
            while (cursor.moveToNext())
            {
                int id =cursor.getInt(cursor.getColumnIndex("id"));
                String name1 =cursor.getString(cursor.getColumnIndex("name"));
                String autograph =cursor.getString(cursor.getColumnIndex("autograph"));
                //System.out.println("----------------查询完成-"+id+name1+autograph);
                Log.i(TAG, "select_person: "+name1);
            }
        }
      //  String  myname = cursor.getString(cursor.getColumnIndex("autograph"));
        Log.i(TAG, "select_person: 查询成功");
        cursor.close();
        sdb.close();
    }
    String name1;

    //查找最后一个id
    public  String  select_person2 ()
    {
        SQLiteDatabase sdb=dbHelper.getReadableDatabase( );
        String sql="select * from person   ORDER BY id DESC LIMIT 1";

     //   Cursor cursor=sdb.rawQuery(sql,new String[ ] { id+""} );
        Cursor cursor=sdb.rawQuery(sql,null);
        // cursor.moveToFirst();
        if(cursor.getCount() !=0)
        {
            while (cursor.moveToNext())
            {
               int myid =cursor.getInt(cursor.getColumnIndex("id"));
             name1 =cursor.getString(cursor.getColumnIndex("name"));
                String autograph =cursor.getString(cursor.getColumnIndex("autograph"));
                System.out.println("----------------昵称-"+myid+name1+autograph);
                Log.i(TAG, "select_person: "+name1);
            }
        }
        //  String  myname = cursor.getString(cursor.getColumnIndex("autograph"));
        Log.i(TAG, "select_person: 查询成功");
        cursor.close();
        sdb.close();
        return name1;
    }

    String autograph_;

    //查找
    public  String  select_person3 ()
    {
        SQLiteDatabase sdb=dbHelper.getReadableDatabase( );
        String sql="select * from person  ORDER BY id DESC LIMIT 1 ";

        Cursor cursor=sdb.rawQuery(sql,null);


        if(cursor.getCount() !=0)
        {
            while (cursor.moveToNext())
            {
                int myid =cursor.getInt(cursor.getColumnIndex("id"));
                String name =cursor.getString(cursor.getColumnIndex("name"));
                autograph_ =cursor.getString(cursor.getColumnIndex("autograph"));
                    System.out.println("----------------        签名-"+myid+name1+autograph_);
                Log.i(TAG, "select_person: "+name1);
            }
        }
        //  String  myname = cursor.getString(cursor.getColumnIndex("autograph"));
        Log.i(TAG, "select_person: 查询成功");
        cursor.close();
        sdb.close();
        return autograph_;
    }



    //查询性别
    String sex;
     public  String select_person_sex()
     {
         SQLiteDatabase sdb=dbHelper.getReadableDatabase( );
         String sql="select * from person  ORDER BY id DESC LIMIT 1 ";

         Cursor cursor=sdb.rawQuery(sql,null);


         if(cursor.getCount() !=0)
         {
             while (cursor.moveToNext())
             {
                 int myid =cursor.getInt(cursor.getColumnIndex("id"));
                 String name =cursor.getString(cursor.getColumnIndex("name"));
                 autograph_ =cursor.getString(cursor.getColumnIndex("autograph"));
                  sex  =cursor.getString(cursor.getColumnIndex("sex"));
                 System.out.println("----------------sex-"+myid+name1+autograph_);
                 Log.i(TAG, "select_person_sex: "+sex);
             }
         }
         Log.i(TAG, "select_person_sex: 查询成功");
         cursor.close();
         sdb.close();
         return sex;
     }

}
