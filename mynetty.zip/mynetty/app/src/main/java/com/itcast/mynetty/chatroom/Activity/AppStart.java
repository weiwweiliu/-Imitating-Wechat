package com.itcast.mynetty.chatroom.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.itcast.mynetty.R;

public class AppStart extends AppCompatActivity {

    private static final String EXTRA_KEY_SELECT_RESULT="Result"  ;
    private Boolean first_run;
     final int CODE_ALBUM_ADD_PIC_FROM_CLOUD = 1,requestCode1=1;


//    ActivityResultLauncher launcher = registerForActivityResult(new ResultContract(), new ActivityResultCallback<String>() {
//        @Override
//        public void onActivityResult(String result) {
//           // Toast.makeText(AppStart.this, result, Toast.LENGTH_SHORT).show();
//            System.out.println("----------------------------"+result);
//        }
//    });


//    class ResultContract extends ActivityResultContract<Boolean, String> {
//        @NonNull
//        @Override
//        public Intent createIntent(@NonNull Context context, Boolean input) {
//            Intent intent = new Intent(AppStart.this, LoginActivity.class);
//            intent.putExtra("b", input);
//            return intent;
//        }
//
//        @Override
//        public String parseResult(int resultCode, @Nullable Intent intent) {
//            assert intent != null;
//            if (intent.getStringExtra("s").isEmpty())
//            {
//                System.out.println("错误没用值_____________________");
//            }
//            return intent.getStringExtra("s");
//        }
//    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.appstart);






        firstRun();

    }

    private void firstRun( ) {
        SharedPreferences sharedPreferences = getSharedPreferences("FirstRun",0);
         first_run = sharedPreferences.getBoolean("First",true);
        if (first_run ){

            sharedPreferences.edit().putBoolean("First",false).apply();
         //   Toast.makeText(this,"第一次",Toast.LENGTH_LONG).show();
            new Handler().postDelayed(new Runnable() {

                public void run() {
                    // TODO 自动生成的方法存根
               //     launcher.launch(true);
                    Intent intent =new Intent(AppStart.this, LoginActivity.class);//在第（二）节内容中实现此类
                    startActivity(intent);
                    //Android页面跳转回调传值
                    //第一个参数：一个Intent对象，用于携带将跳转至下一个界面中使用的数据，使用putExtra(A,B)方法，此处存储的数据类型特别多，基本类型全部支持。
                    //
                    //第二个参数：如果> = 0,当Activity结束时requestCode将归还在onActivityResult()中。以便确定返回的数据是从哪个Activity中返回，用来标识目标activity。
                    //
              //      startActivityForResult(intent, requestCode1);
               //     AppStart.this.finish();


                }
            }, 5000); //持续5s

        }
        else {
            new Handler().postDelayed(new Runnable() {

                public void run() {
                    // TODO 自动生成的方法存根

                    Intent intent =new Intent(AppStart.this, Index.class);//在第（二）节内容中实现此类

                    startActivity(intent);

                    AppStart.this.finish();

                }
            },0); //持续0s
          //  Toast.makeText(this,"不是第一次",Toast.LENGTH_LONG).show();
        }
    }



    //回调函数
//第一个参数：这个整数requestCode用于与startActivityForResult中的requestCode中值进行比较判断，是以便确认返回的数据是从哪个Activity返回的。
//第二个参数：这整数resultCode是由子Activity通过其setResult()方法返回。适用于多个activity都返回数据时，来标识到底是哪一个activity返回的值。
//第三个参数：一个Intent对象，带有返回的数据。可以通过data.getXxxExtra( );方法来获取指定数据类型的数据
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
////        if (resultCode == RESULT_OK) {
////            switch (requestCode) {
////                case CODE_ALBUM_ADD_PIC_FROM_CLOUD:
////                    String selectResult = data.getStringExtra(EXTRA_KEY_SELECT_RESULT);
////                    selectResult.length();
////                    Log.i("TAG", "onActivityResult:-------------- "+ selectResult);
////                    System.out.println("_++_+++++++++++++++++++++++++++++"+selectResult.length());
////                    break;
////                default:
////                    break;
////            }
////        }
//        if (requestCode == 1 && resultCode == 3) {
//            String result = data.getStringExtra("result");
//          //  textView.setText(result);
//            Log.i("TAG", "onActivityResult:-------------- "+ result);
//        }
//
//    }
}
