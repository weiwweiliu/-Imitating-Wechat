package com.itcast.mynetty.chatroom.Activity.secondaryActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.itcast.mynetty.R;
import com.itcast.mynetty.chatroom.Activity.ChatRoom;

/**
 * 2020 12 21
 * @version v1.0
 */
//朋友的个人信息页面
public class Friendspage extends AppCompatActivity implements View.OnClickListener {

    private TextView friendName,userID;
    private ImageButton friendImage;
    private Button sendbutton;
    private  String  ContactName;
    private   int userId;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friendpage);
//接收数据
        Bundle bundle = getIntent().getExtras();
         userId = bundle.getInt("userId");
         ContactName = bundle.getString("ContactName");



        friendName =findViewById(R.id.friendName);
      sendbutton=(Button)findViewById(R.id.sendbutton);
        friendImage=(ImageButton)findViewById(R.id.friendImage);
        friendName.setText(ContactName);
        friendImage.setImageResource(userId);
        sendbutton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v==sendbutton){
            Bundle bundle = new Bundle();
            bundle.putInt("photo", userId);
          //  bundle.putString("message", message[arg2]);
            bundle.putString("name",ContactName);
            Intent intent = new Intent();
            intent.setClass(Friendspage.this,ChatRoom.class);
            intent.putExtras(bundle);

            startActivity(intent);
        }
    }
}
