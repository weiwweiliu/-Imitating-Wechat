package com.itcast.mynetty.chatroom;

//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentManager;
//import android.support.v4.app.FragmentPagerAdapter;
import android.os.Build;
import android.view.ViewGroup;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.itcast.mynetty.chatroom.Activity.Contact;
import com.itcast.mynetty.chatroom.Activity.FragmentSet;
import com.itcast.mynetty.chatroom.Activity.Index;
import com.itcast.mynetty.chatroom.Activity.MyMessage;
import com.itcast.mynetty.chatroom.Activity.News;

/**
 *
 * 2020  5 18
 * @author  weiwei
 * @version  1.0
 */
//工具类  实现滑动切换页面 ，公共部分设置
public class MyFragmentPagerAdapter extends FragmentPagerAdapter {

    private final int PAGER_COUNT = 4;
    private Fragment myFragment1 = null;
    private Fragment myFragment2 = null;
    private Fragment myFragment3 = null;
    private Fragment myFragment4 = null;


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public MyFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
        myFragment1 = new News();
        myFragment2 = new Contact();
        myFragment3 = new FragmentSet();
        myFragment4 =new MyMessage();

    }

    @Override
    public int getCount() {
        return PAGER_COUNT;
    }

    @Override
    public Object instantiateItem(ViewGroup vg, int position) {
        return super.instantiateItem(vg, position);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        System.out.println("position Destory" + position);
        super.destroyItem(container, position, object);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case Index.PAGE_ONE:
                fragment = myFragment1;
                break;
            case Index.PAGE_TWO:
                fragment = myFragment2;
                break;
            case Index.PAGE_THREE:
                fragment = myFragment3;
                break;
            case Index.PAGE_FOUR:
                fragment = myFragment4;
                break;
        }
        return fragment;
    }

}

