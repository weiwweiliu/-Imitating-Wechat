package com.itcast.mynetty.chatroom.Entity;

public class MyUser {
    private String name;
    private long price;
    private String des;
    private int viewType;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public MyUser() {

    }

    public MyUser(String name, long price, String des, int viewType) {
        this.name = name;
        this.price = price;
        this.des = des;
        this.viewType = viewType;
    }

    @Override
    public String toString() {
        return "MyUser{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", des='" + des + '\'' +
                ", viewType=" + viewType +
                '}';
    }
}
