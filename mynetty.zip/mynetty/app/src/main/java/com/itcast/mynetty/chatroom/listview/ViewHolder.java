package com.itcast.mynetty.chatroom.listview;


import android.widget.ImageView;
import android.widget.TextView;

//
public class ViewHolder {

    public TextView title,explanation,date;

   public ImageView list_iv;

}
