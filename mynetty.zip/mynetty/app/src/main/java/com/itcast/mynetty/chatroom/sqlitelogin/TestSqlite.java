package com.itcast.mynetty.chatroom.sqlitelogin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.itcast.mynetty.chatroom.sqlitelogin.service.PersonService;
import com.itcast.mynetty.chatroom.sqlitelogin.test.Person;
import com.itcast.mynetty.R;

/**
 * //测试类 无   2020  5 18
 */

public class TestSqlite extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        Button  insert =(Button) findViewById(R.id.insert);
        Button select = (Button) findViewById(R.id.select);
        Button update = (Button) findViewById(R.id.update);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String name= "李四";
                String autograph=" 错错错";
                String  sexstr ="男";
                PersonService personService=new PersonService(TestSqlite.this);
                Person person =new Person();
                person.setName(name);
                person.setAutograph(autograph);
                person.setSex(sexstr);
                personService.insert_person(person);
            }
        });

//                    select.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        PersonService personService=new PersonService(TestSqlite.this);
//                        personService.select_person("maliu");
//                    }
//                });

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonService personService=new PersonService(TestSqlite.this);
                personService.select_person_sex();
            }
        });

//        select.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                PersonService personService=new PersonService(TestSqlite.this);
//                String s = personService.select_person2(1);
//                Log.i("TAG", "onClick: s =========="+s);
//            }
//        });

//                    update.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            PersonService personService=new PersonService(TestSqlite.this);
//                            personService.update_person(3,"王五111");
//                            Toast.makeText(TestSqlite.this,"修改成功",Toast.LENGTH_SHORT).show();
//                        }
//                    });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonService personService=new PersonService(TestSqlite.this);
                personService.update_person2(2,"女");
                Toast.makeText(TestSqlite.this,"修改成功",Toast.LENGTH_SHORT).show();
            }
        });

       // personService.update_person(1,"dd");
      //  personService.select_person(1);
    }


}
